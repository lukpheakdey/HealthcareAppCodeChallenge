
<style>
    .top-padding {
        padding-bottom: 10%;
    }
</style>

@extends('layouts.app')

