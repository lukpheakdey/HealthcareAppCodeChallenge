<?php $__env->startSection('content'); ?>
    <form action="/signup" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-row">
            <div class="form-group col-md-6">
                <label> Name </label>
                <input type="text" class="form-control" id="name" name="name">
            </div>
            <div class="form-group col-md-2">
                <label> Age </label>
                <input type="number" class="form-control" id="age" name="age">
            </div>
            <div class="form-group col-md-4">
                <label> Phone </label>
                <input type="text" class="form-control" id="phone" name="phone">
            </div>
        </div>
        <button type="submit" class="btn btn-outline-success">Sign up</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/HealthcareAppCodeChallenge/axxess_challenge/resources/views/patient/signup.blade.php ENDPATH**/ ?>