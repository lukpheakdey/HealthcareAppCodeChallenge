<?php $__env->startSection('content'); ?>
    <table class="table table-hover">
        <thead>
        <tr>
            <th scope="col">Id</th>
            <th scope="col">Name</th>
            <th scope="col">Age</th>
            <th scope="col">Phone</th>
            <th scope="col">Start Date</th>
            <th scope="col">Deadline</th>
            <th scope="col">Expired Date </th>
            <th scope="col">Remaining Day </th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"> <?php echo e($patient->id); ?> </th>
                <td> <?php echo e($patient->name); ?> </td>
                <td> <?php echo e($patient->age); ?> </td>
                <td> <?php echo e($patient->phone); ?> </td>
                <td> <?php echo e(date('m-d-Y', strtotime($patient->start_date))); ?> </td>
                <td> <?php echo e($deadline =  date('m-d-Y', strtotime($patient->deadline))); ?> </td>
                <td> <?php echo e($expiredDate = date('m-d-Y', strtotime(' + 30 days'))); ?> </td>
                <td> <?php echo e($patient->remaining); ?>  </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/HealthcareAppCodeChallenge/axxess_challenge/resources/views/patient/upcoming.blade.php ENDPATH**/ ?>