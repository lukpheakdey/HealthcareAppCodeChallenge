<style>
    .top-padding {
        padding-bottom: 10%;
    }
</style>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/HealthcareAppCodeChallenge/axxess_challenge/resources/views/patient/index.blade.php ENDPATH**/ ?>