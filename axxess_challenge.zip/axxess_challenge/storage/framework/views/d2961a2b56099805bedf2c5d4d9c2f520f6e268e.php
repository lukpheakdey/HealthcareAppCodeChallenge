<?php $__env->startSection('content'); ?>
    <form action="/visit" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-row">
            <div class="form-group col-md-3">
                <label> Patient ID </label>
                <input type="text" class="form-control" id="id" name="id">
            </div>
            <div class="form-group col-md-2">
                <label> Visit Date </label>
                <input type="text" class="form-control" id="datepicker" name="visit_date">
            </div>
        </div>
        <button type="submit" class="btn btn-outline-success">Submit</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/HealthcareAppCodeChallenge/axxess_challenge/resources/views/patient/visit.blade.php ENDPATH**/ ?>